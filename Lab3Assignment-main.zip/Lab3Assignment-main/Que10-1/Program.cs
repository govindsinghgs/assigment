﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Que10_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }
    public class Class1
    {
        public Class1()
        {
            Console.WriteLine("Instance Created !");
        }
    }
}