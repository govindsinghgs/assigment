﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Que3_1;
using System.Runtime.CompilerServices;

namespace Que3_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            class1 c = new class1();
            Console.WriteLine("The value of internal field is : " + c.Value);

        }
    }
}