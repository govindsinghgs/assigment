﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Que10_1;

namespace Que10_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Class1 class1 = new Class1();
        }
    }
}